#!/usr/bin/env python
# coding: utf-8

# In[1]:


import mysql.connector

database = mysql.connector.connect(
    host ="localhost",
    user ="root",
    passwd =""

)

cursorObject = database.cursor()


cursorObject.execute("CREATE DATABASE D3_TI_2023")


# In[2]:


import mysql.connector

dataBase = mysql.connector.connect(
    host ="localhost",
    user ="root",
    passwd ="",
    database ="d3_ti_2023"
)

cursorObject = dataBase.cursor()

studentRecord = """CREATE TABLE Mahasiswa (
                    NIM VARCHAR(10) NOT NULL PRIMARY KEY,
                    NAMA VARCHAR(30) NOT NULL,
                    ALAMAT VARCHAR(255),
                    MATKUL_YANG_DIIKUTI VARCHAR(10)
                    )"""

cursorObject.execute(studentRecord)

dataBase.close()


# In[3]:


import mysql.connector

dataBase = mysql.connector.connect(
    host = "localhost",
    user = "root",
    passwd = "",
    database = "d3_ti_2023"
)

#preparing cursor
cursorObject = dataBase.cursor()

sql = "INSERT INTO Mahasiswa (NIM, NAMA, ALAMAT, MATKUL_YANG_DIIKUTI) VALUES (%s, %s, %s, %s)"
val = [("V3822022",  "AULIA", "TUBAN", "PRAKTIK WEB"),
       ("V322019",  "AYA", "BOJONEGORO", "PYTHON"),
       ("V3822050",  "MALIKA", "LAMONGAN", "STATISTIKA"),
       ("V3822045",  "MAZAYA", "SURABAYA", "BASIS DATA"),
       ("V3822049",  "KEVIN", "SEMARANG", "WIRELESS")
      ]

cursorObject.executemany(sql, val)
dataBase.commit()

#Disconnect
dataBase.close()


# In[4]:


import mysql.connector

dataBase = mysql.connector.connect(
    host ="localhost",
    user ="root",
    passwd ="",
    database ="d3_ti_2023"
)

cursorObject = dataBase.cursor()

studentRecord = """CREATE TABLE Dosen (
                    NIP VARCHAR(20) NOT NULL PRIMARY KEY,
                    NAMA_DOSEN VARCHAR(50) NOT NULL,
                    MATKUL_YANG_DIAJAR VARCHAR(50)
                    )"""

cursorObject.execute(studentRecord)

dataBase.close()


# In[5]:


import mysql.connector

dataBase = mysql.connector.connect(
    host ="localhost",
    user ="root",
    passwd ="",
    database ="d3_ti_2023"
)

cursorObject = dataBase.cursor()

studentRecord = """CREATE TABLE Mata_Kuliah (
                    KODE_MATKUL VARCHAR(10) NOT NULL PRIMARY KEY,
                    NAMA_MATKUL VARCHAR(50) NOT NULL,
                    NAMA_DOSEN VARCHAR(20),
                    WAKTU DATE,
                    RUANGAN VARCHAR(10)
                    )"""

cursorObject.execute(studentRecord)

dataBase.close()


# In[6]:


import mysql.connector

dataBase = mysql.connector.connect(
    host = "localhost",
    user = "root",
    passwd = "",
    database = "d3_ti_2023"
)

#preparing cursor
cursorObject = dataBase.cursor()

sql = "INSERT INTO Mata_kuliah (KODE_MATKUL, NAMA_MATKUL, NAMA_DOSEN, WAKTU, RUANGAN) VALUES (%s, %s, %s, %s, %s)"
val = [("19191919",  "PRAKTIK WEB", "BU MASBAHAH", "2023-1-3", "Lab 2B"),
       ("21212121",  "PYTHON", "PAK YUSUF", "2023-1-3", "Lab 1A"),
       ("74747474",  "STATISTIKA", "BU TRISNA", "2023-1-1", "Lab 1B"),
       ("32323232",  "BASIS DATA", "PAK MASBAHAH", "2023-1-2", "2B"),
       ("98989898",  "WIRELESS", "BU MYUSUF", "2023-1-5", "Lab 2A")
      ]

cursorObject.executemany(sql, val)
dataBase.commit()

#Disconnect
dataBase.close()


# In[7]:


import mysql.connector

dataBase = mysql.connector.connect(
    host = "localhost",
    user = "root",
    passwd = "",
    database = "d3_ti_2023"
)

#preparing cursor
cursorObject = dataBase.cursor()

query = "SELECT NAMA_MATKUL, NAMA_DOSEN FROM Mata_Kuliah"
cursorObject.execute (query)

myresult = cursorObject.fetchall()

for x in myresult:
    print(x)
    
dataBase.close()


# In[ ]:




